var config = {
    config: {
        mixins: {
            'Magento_Paypal/js/view/payment/method-renderer/in-context/checkout-express': {
                'Amasty_InvisibleCaptcha/js/view/paypal/in-context/checkout-express-mixin': true
            }
        }
    }
};
