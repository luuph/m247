var config = {
    map: {
        '*': {
            optionsContent: 'Amasty_ShopbyBase/js/options-content',
            chosen: 'Amasty_ShopbyBase/js/chosen/chosen.jquery'
        }
    }
};
