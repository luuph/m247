var config = {
    map: {
        '*': {
            amShopbyTooltipInit: 'Amasty_ShopbyBase/js/components/am-tooltip-init'
        }
    }
};
