<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package Shop by Brand for Magento 2
 */

namespace Amasty\ShopbyBrand\Controller;

class RegistryConstants
{
    public const FEATURED = 'amasty_shopbybrand_featured';
}
