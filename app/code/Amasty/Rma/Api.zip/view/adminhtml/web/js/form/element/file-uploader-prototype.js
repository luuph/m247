define([
    'Magento_Ui/js/form/element/file-uploader',
    'prototype'
], function (fileUploader) {
    return fileUploader;
});
