define([
    'uiElement'
], function (Element) {
    'use strict';

    return Element.extend({
        defaults: {
            template: 'Amasty_Rma/grid/amrma-addons',
            modulesData: ''
        }
    });
});
