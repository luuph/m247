var config = {
    map: {
        "*": {
            amslAnalytic: "Amasty_SocialLogin/js/amsl-analytic",
        }
    }
};
