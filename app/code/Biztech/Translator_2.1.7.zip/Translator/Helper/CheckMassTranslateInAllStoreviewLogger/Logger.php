<?php
namespace Biztech\Translator\Helper\CheckMassTranslateInAllStoreviewLogger;

class Logger extends \Monolog\Logger
{

}
