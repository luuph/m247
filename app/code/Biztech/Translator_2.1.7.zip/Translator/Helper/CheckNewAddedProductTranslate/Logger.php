<?php
namespace Biztech\Translator\Helper\CheckNewAddedProductTranslate;

class Logger extends \Monolog\Logger
{

}
