<?php
/** Copyright © 2016 store.biztechconsultancy.com. All Rights Reserved. **/

namespace Biztech\Translator\Helper\Cron;

class Logger extends \Monolog\Logger
{

}
