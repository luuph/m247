<?php
namespace Biztech\Translator\Helper\MassTranslateInAllStoreviewLogger;

class Logger extends \Monolog\Logger
{

}
