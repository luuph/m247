<?php
namespace Biztech\Translator\Helper\NewAddedProductTranslate;

class Logger extends \Monolog\Logger
{

}
