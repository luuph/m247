<?php
/**
 * FME RestrictPaymentMethod Module registration.
 * @package   FME_RestrictPaymentMethod
 * @copyright Copyright (c) 2019 United Sol Private Limited (https://unitedsol.net)
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'FME_RestrictPaymentMethod',
    __DIR__
);
