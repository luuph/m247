<?php
/**
 * Copyright © 2020 MageXtensions. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageXtensions\TntExpressConnect\Model\Config\Source;

use Magento\Framework\App\ObjectManager;
use MageXtensions\TntExpressConnect\Model\Carrier;

/**
 * Class Services
 * @package MageXtensions\TntExpressConnect\Model\Config\Source
 */
class Services implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * List of TNT Express services
     *
     * @return array
     */
    public function toOptionArray()
    {
        $ukServices = [
            ['value' => '1', 'label' => __('Express (UK)')],
            ['value' => 'AM', 'label' => __('12:00 Express (UK)')],
            ['value' => 'BN', 'label' => __('09:00 Express (UK)')],
            ['value' => 'BT', 'label' => __('10:00 Express (UK)')],
        ];

        return array_merge(
            [
                ['value' => '09N', 'label' => __('09:00 Express')],
                ['value' => '10N', 'label' => __('10:00 Express')],
                ['value' => '12N', 'label' => __('12:00 Express')],
                ['value' => '412', 'label' => __('12:00 Economy Express')],
                ['value' => '15N', 'label' => __('Express')],
                ['value' => '15', 'label' => __('Domestic Express')],
                ['value' => '48N', 'label' => __('Economy Express')],
                ['value' => '29', 'label' => __('IDE Express')],
                ['value' => '30', 'label' => __('IDE Economy')],
            ],
            $this->getConfigData('tnt_country') == 'GB' ? $ukServices : []
        );
    }

    /**
     * Retrieve information from carrier configuration
     *
     * @param   string $field
     * @return  false|string
     */
    public function getConfigData($field)
    {
        $path = 'carriers/' . Carrier::CODE . '/' . $field;

        $_objectManager = ObjectManager::getInstance();
        $scopeConfig = $_objectManager
            ->get('Magento\Framework\App\Config\ScopeConfigInterface');

        return $scopeConfig->getValue(
            $path,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
}
