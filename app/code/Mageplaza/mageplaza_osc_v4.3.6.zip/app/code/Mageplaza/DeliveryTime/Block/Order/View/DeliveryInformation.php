<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_DeliveryTime
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\DeliveryTime\Block\Order\View;

use Mageplaza\DeliveryTime\Block\DeliveryInformation as DeliveryInformationAbstract;

/**
 * Class DeliveryInformation
 * @package Mageplaza\DeliveryTime\Block\Order\View
 */
class DeliveryInformation extends DeliveryInformationAbstract
{
    /**
     * Get current order
     *
     * @return mixed
     */
    public function getOrder()
    {
        return $this->registry->registry('current_order');
    }

    /**
     * @return string
     */
    public function getPageType()
    {
        return 'order';
    }
}
