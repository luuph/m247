<?php

declare(strict_types=1);

namespace MaxMind\Exception;

class IpAddressNotFoundException extends InvalidRequestException
{
}
