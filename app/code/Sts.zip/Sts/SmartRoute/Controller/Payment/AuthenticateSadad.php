<?php

namespace Sts\SmartRoute\Controller\Payment;

use Magento\Quote\Api\CartManagementInterface;

class ApiPayment extends \Magento\Framework\App\Action\Action {

    /**
     * Customer session model
     *
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;
    protected $_resultPageFactory;

    /*
     * @var \Sts\SmartRoute\Model\PaymentMethod
     */
    protected $_paymentMethod;
    protected $_checkoutSession;
    protected $checkout;

    /**
     *
     * @var \Magento\Quote\Model\QuoteManagement
     */
    protected $cartManagement;
    protected $orderRepository;
    protected $_scopeConfig;

    /**
     * json factory
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $resultPageFactory;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Customer\Model\Session $customerSession
     */
    public function __construct(
    \Magento\Framework\App\Action\Context $context, \Magento\Customer\Model\Session $customerSession, \Sts\SmartRoute\Model\PaymentMethod $paymentMethod, \Magento\Checkout\Model\Session $checkoutSession, \Magento\Sales\Api\OrderRepositoryInterface $orderRepository, \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig, CartManagementInterface $cartManagement, \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->_customerSession = $customerSession;
        parent::__construct($context);
        $this->_paymentMethod = $paymentMethod;
        $this->_checkoutSession = $checkoutSession;
        $this->cartManagement = $cartManagement;
        $this->orderRepository = $orderRepository;
        $this->_scopeConfig = $scopeConfig;
        $this->_resultPageFactory = $resultPageFactory;
    }

    public function execute() {
        //$order = $this->_checkoutSession->getLastRealOrder();
        
        $pageResult = $this->resultFactory->create(ResultFactory::TYPE_PAGE);        
        $pageResult->addHandle('smartroute_payment_apipayment');        
        $viewData = array();
        $viewData['ibUrl'] = $this->_checkoutSession->getIbUrl();        
        $viewData['responseMfu'] = $this->_checkoutSession->getResponseMfu();        
        $viewData['responseEstn'] = $this->_checkoutSession->getResponseEstn();        
        $pageResult->getLayout()->getBlock('smartroute_authenticate_sadad_form')->setData($viewData);
        
        return $pageResult;  
    }
}