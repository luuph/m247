<?php 

namespace Sts\SmartRoute\Controller\Payment; 


use Magento\Framework\Controller\ResultFactory;


class Cancel extends \Magento\Framework\App\Action\Action
{
    /**
     * Customer session model
     *
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;
    protected $resultPageFactory;
    protected $checkoutSession;
    protected $orderRepository;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Customer\Model\Session $customerSession
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Checkout\Model\Session $checkoutSession
    ) {
        $this->_customerSession = $customerSession;
        $this->checkoutSession = $checkoutSession;
        $this->orderRepository = $orderRepository;
        parent::__construct($context);
    }

    public function execute()
    {
        $cancelMsg = __('Payment has been cancelled.');        
                
        $order = null;                
        if($this->checkoutSession->getLastOrderId()){            
            $order = $this->orderRepository->get($this->checkoutSession->getLastOrderId());
            $this->checkoutSession->restoreQuote();
        }       
        
            if ($order) {
                //change order status to cancel
                $order->cancel();
                $order->addStatusToHistory(\Magento\Sales\Model\Order::STATE_CANCELED, $cancelMsg);
                $order->save();
            }
        
            $statusCode = $this->getRequest()->getParam('statusCode', '');
            $statusDescription = $this->getRequest()->getParam('statusDesc', '');
            $transactionId = $this->getRequest()->getParam('TransactionId', null);            
            
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $getLocale = $objectManager->get('Magento\Framework\Locale\Resolver');
            $haystack  = $getLocale->getLocale(); 
            $lang = strstr($haystack, '_', true);         

            $viewData = [
                'OrderId' => $order->getIncrementId(),
                'TransactionId' => !empty($transactionId)?$transactionId:($order?$order->getPayment()->getLastTransId():''),
                'OrderStatus' => $order->getStatus(),
                'Status' => $statusCode,
                'StatusDescription' => $statusDescription,                
                'lang' => $lang,
            ];

        if($this->getRequest()->getParam('redirect_home')){
            /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */            
            $resultRedirect = $this->resultRedirectFactory->create();
            $resultRedirect->setPath('/');
            return $resultRedirect;
        }else{
            $pageResult = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
            $pageResult->addHandle('smartroute_payment_cancel');
            $pageResult->getLayout()->getBlock('smartroute_payment_cancel')->setData($viewData);
            return $pageResult;
	}
    }
}


