<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Sts\SmartRoute\Model\Config;

/**
 * Options provider for full countries list
 *
 * @api
 *
 * @codeCoverageIgnore
 * @since 100.0.2
 */
class CommunicationModel implements \Magento\Framework\Option\ArrayInterface
{
    CONST COMMUNICATION_MODEL_DIRECT_POST = 1;
    CONST COMMUNICATION_MODEL_REDIRECT = 2;
    CONST COMMUNICATION_MODEL_API = 3;
    
    public static $communication_models = array(
        self::COMMUNICATION_MODEL_DIRECT_POST => 'Direct Post',
        self::COMMUNICATION_MODEL_REDIRECT => 'Redirect',
        //self::COMMUNICATION_MODEL_API => 'API', //API not used currently
    );

    private $_options;
    
    /**
     * @param bool $isMultiselect
     * @return array
     */
    public function toOptionArray($isMultiselect = false)
    {
        if (!$this->_options) {
            $this->_options = self::$communication_models;
        }

        $options = $this->_options;
        if (!$isMultiselect) {
            array_unshift($options, ['value' => '', 'label' => __('--Please Select--')]);
        }

        return $options;
    }
}
