<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Sts\SmartRoute\Model\Config;

/**
 * Options provider for full countries list
 *
 * @api
 *
 * @codeCoverageIgnore
 * @since 100.0.2
 */
class SadadCreditModel implements \Magento\Framework\Option\ArrayInterface
{
    CONST METHOD_TYPE_CREDIT_CARD = 'creditcard';
    CONST METHOD_TYPE_SADAD = 'sadad';    
    
    public static $payment_methods_models = array(
        self::METHOD_TYPE_CREDIT_CARD => 'Credit Card',
        self::METHOD_TYPE_SADAD => 'Sadad',        
    );

    private $_options;
    
    /**
     * @param bool $isMultiselect
     * @return array
     */
    public function toOptionArray($isMultiselect = false)
    {
        if (!$this->_options) {
            $this->_options = self::$payment_methods_models;
        }

        $options = $this->_options;
        if (!$isMultiselect) {
            array_unshift($options, ['value' => '', 'label' => __('Both (Credit Card/Sadad)')]);
        }

        return $options;
    }
}
