<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Sts\SmartRoute\Model\Ui;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\Locale\ResolverInterface;
use Magento\Customer\Helper\Session\CurrentCustomer;
use Magento\Payment\Helper\Data as PaymentHelper;

/**
 * Class ConfigProvider
 */
final class ConfigProvider implements ConfigProviderInterface
{
    const CODE = 'smartroute';

    /**
     * @var ResolverInterface
     */
    protected $localeResolver;

    /**
     * @var Config
     */
    protected $config;

    /**
     * @var \Magento\Customer\Helper\Session\CurrentCustomer
     */
    protected $currentCustomer;

    /**
     * @var \Magento\Payment\Model\Method\AbstractMethod[]
     */
    protected $methods = [];

    /**
     * @var PaymentHelper
     */
    protected $paymentHelper;
    
    protected $checkoutSession;
    
    /**
     * constructor of config provider
     * @param ResolverInterface $localeResolver
     * @param CurrentCustomer $currentCustomer
     * @param \Magento\Checkout\Model\Session $checkoutSession    
     * @param PaymentHelper $paymentHelper
     */
    public function __construct(
        //ConfigFactory $configFactory,
        ResolverInterface $localeResolver,
        CurrentCustomer $currentCustomer,
        \Magento\Checkout\Model\Session $checkoutSession,        
        PaymentHelper $paymentHelper
    ) {
        $this->localeResolver = $localeResolver;
        $this->currentCustomer = $currentCustomer;
        $this->paymentHelper = $paymentHelper;
        $this->checkoutSession = $checkoutSession;        
        
        $code = self::CODE;
        $this->methods[$code] = $this->paymentHelper->getMethodInstance($code);
    }
    
    /**
     * {@inheritdoc}
     */
    public function getConfig()
    {
        $code = self::CODE;
        $config = [];
        
        
        if ($this->methods[self::CODE]->isAvailable($this->checkoutSession->getQuote())) {
            $config = [];
            $config['payment'] = [];            
            $config['payment'][$code]['redirectUrl'] = $this->getMethodRedirectUrl($code);
            
        }
        
        return $config;
    }

    /**
     * Return redirect URL for method
     *
     * @param string $code
     * @return mixed
     */
    protected function getMethodRedirectUrl($code)
    {
        return $this->methods[$code]->getOrderPlaceRedirectUrl();
    }
}
