<?php
/**
 * Copyright © 2017 STS SmartRoute. All rights reserved.
 * See COPYING.txt for license details.
 */

use \Magento\Framework\Component\ComponentRegistrar;

\Magento\Framework\Component\ComponentRegistrar::register(
    ComponentRegistrar::MODULE,
    'Sts_SmartRoute',
    __DIR__
);
