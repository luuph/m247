define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (Component,
              rendererList) {
        'use strict';
        rendererList.push(
            {
                type: 'smartroute',
                component: 'Sts_SmartRoute/js/view/payment/method-renderer/smartroute-method'
            }
        );
        return Component.extend({});
    }
);
