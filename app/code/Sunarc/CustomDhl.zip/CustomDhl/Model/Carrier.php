<?php
/**
Description:  Aramex Shipping Magento2 plugin
Version:      1.0.0
Author:       aramex.com
Author URI:   https://www.aramex.com/solutions-services/developers-solutions-center
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
 */
namespace Sunarc\CustomDhl\Model;

use Magento\Catalog\Model\Product\Type;
use Magento\Framework\Module\Dir;
use Magento\Sales\Exception\DocumentValidationException;
use Magento\Sales\Model\Order\Shipment;
use Magento\Quote\Model\Quote\Address\RateRequest;
use Magento\Quote\Model\Quote\Address\RateResult\Error;
use Magento\Shipping\Model\Carrier\AbstractCarrier;
use Magento\Shipping\Model\Rate\Result;
use Magento\Framework\Xml\Security;
use Magento\Dhl\Model\Validator\XmlValidator;
   
class Carrier extends \Magento\Dhl\Model\Carrier
{

   public $jordonCityArray = array("عجلون" => "Ajloon","الهاشمية" => "Al Hashmyeh","الجفر" => "Al Jafer","حدود العمري" => "Al Omari Borders","القصر" => "Al Qaser","القسطل" => "Al Qastal","الرصيفة" => "Al Rosaifa","السخنة" => "Al Sukhneh","عمان" => "Amman","العقبة" => "Aqaba","الازرق" => "Azraq","بيرين" => "Bereian","دير علا" => "Der Allah","المنطقة الحرة" => "Free Zone"," الفحيص" => "Fuhais","الغور " => "Ghour","غور الصافي" => "Ghour Al Safi","الغويرية" => "Ghweria","إربد" => "Irbid","جرش" => "Jerash","الكرك" => "Karak","الخالدية" => "Khaldieh","معان" => "Ma'An","مأدبا" => "Madaba","معين" => "Maean","المفرق" => "Mafraq","ماحص" => "Mahes","مؤتةا" => "Moatah","مخيم حطين" => "Moghayam Hetein","الموقر" => "Mwaqar","ناعور" => "Naour","البترا" => "Petra","القويرية" => "Qwaireh","الرمثا" => "Ramtha","الرشادية" => "Rashadyeh","الرويشد" => "Rwaished","السلط" => "Salt","الشوبك" => "Shoubak","الشونة" => "Shouneh","الطفيلة" => "Tafileh","ذيبان" => "Theban"," وادي موسى" => "Wadi Mousa","يجوز" => "Yajoz","الزرقاء" => "Zarqa","الزرقاء الجديدة" => "Zarqa' Al Jadedeh");

    public $CityArrayWW = array(
        'AF'=>'Kabul',
        'AX'=>'Mariehamn',
        'AL'=>'Tirana',
        'DZ'=>'Algiers',
        'AS'=>'Pago Pago',
        'AD'=>'Andorra la Vella',
        'AO'=>'Luanda',
        'AI'=>'The Valley',
        'AQ'=>'Maxwell Bay',
        'AG'=>'Saint John s',
        'AR'=>'Buenos Aires',
        'AM'=>'Yerevan',
        'AW'=>'Oranjestad',
        'AU'=>'Canberra',
        'AT'=>' Vienna',
        'AZ'=>'Baku',
        'BS'=>'Nassau',
        'BH'=>'Manama',
        'BD'=>'Dhaka',
        'BB'=>'Bridgetown',
        'BY'=>'Minsk',
        'BE'=>'Brussels',
        'BZ'=>'Belmopan',
        'BJ'=>'Cotonou',
        'BM'=>'Hamilton',
        'BT'=>'Thimphu',
        'BO'=>'La Paz; Sucre',
        'BA'=>'Sarajevo',
        'BW'=>'Gaborone',
        'BV'=>'Bouvet Island',
        'BR'=>'Brasilia',
        'IO'=>'Camp Justice',
        'VG'=>'Road Town',
        'BN'=>'Bandar Seri Begawan',
        'BG'=>'Sofia',
        'BF'=>'Ouagadougou',
        'BI'=>'Gitega ',
        'KH'=>'Phnom Penh',
        'CM'=>'Yaounde',
        'CA'=>'Ottawa',
        'CV'=>'Praia',
        'KY'=>'George Town',
        'CF'=>'Bangui',
        'TD'=>'N Djamena',
        'CL'=>'Santiago',
        'CN'=>'Beijing',
        'CX'=>'Flying Fish Cove',
        'CC'=>'West Island',
        'CO'=>'Bogota',
        'KM'=>'Moroni',
        'CG'=>'Brazzaville',
        'CD'=>'Kinshasa',
        'CK'=>'Avarua',
        'CR'=>'San Jose',
        'CI'=>'Abidjan',
        'HR'=>'Zagreb',
        'CU'=>'Havana',
        'CY'=>'Nicosia',
        'CZ'=>'Prague',
        'DK'=>'Copenhagen',
        'DJ'=>'Djibouti',
        'DM'=>'Roseau',
        'DO'=>'Santo Domingo',
        'EC'=>'Quito',
        'EG'=>'Cairo',
        'SV'=>'San Salvador',
        'GQ'=>'Malabo',
        'ER'=>'Asmara',
        'EE'=>'Tallinn',
        'ET'=>'Addis Ababa',
        'FK'=>'Stanley',
        'FO'=>'Tórshavn',
        'FJ'=>'Suva',
        'FI'=>'Helsinki',
        'FR'=>'Parris',
        'GF'=>'Cayenne',
        'PF'=>'Papeete',
        'TF'=>'Saint-Pierre',
        'GA'=>'Libreville',
        'GM'=>'Banjul',
        'GE'=>'Tbilisi',
        'DE'=>'Berlin',
        'GH'=>'Accra',
        'GI'=>'Gibraltar',
        'GR'=>'Athens',
        'GL'=>'Nuuk',
        'GD'=>'Saint George s',
        'GP'=>'Basse-Terre',
        'GU'=>'Hagåtña',
        'GT'=>'Guatemala City',
        'GG'=>'Saint Peter Port',
        'GN'=>'Conakry',
        'GW'=>'Bissau',
        'GY'=>'GGGeorgetown',
        'HT'=>'Port-au-Prince',
        'HM'=>'Heard Island',
        'HN'=>'Tegucigalpa',
        'HK'=>'Central',
        'HU'=>'Budapest',
        'IS'=>'Reykjavik',
        'IN'=>'New Delhi',
        'ID'=>'Jakarta',
        'IR'=>'Tehran',
        'IQ'=>'Baghdad',
        'IE'=>'Dublin',
        'IM'=>'Douglas',
        'IL'=>'Tel Aviv; Jerusalem',
        'IT'=>'Rome',
        'JM'=>'Kingston',
        'JP'=>'Tokyo',
        'JE'=>'Saint Helier',
        'JO'=>'Amman',
        'KZ'=>'Astana',
        'KE'=>'Nairobi',
        'KI'=>'Tarawa Atoll',
        'KW'=>'Kuwait City',
        'KG'=>'Bishkek',
        'LA'=>'Vientiane',
        'LV'=>'Riga',
        'LB'=>'Beirut',
        'LS'=>'Maseru',
        'LR'=>'Monrovia',
        'LY'=>'Tripoli',
        'LI'=>'Vaduz',
        'LT'=>'Vilnius',
        'LU'=>'Luxembourg',
        'MO'=>'Beijing',
        'MK'=>'Skopje',
        'MG'=>'Antananarivo',
        'MW'=>'Lilongwe',
        'MY'=>'Kuala Lumpur',
        'MV'=>'Male',
        'ML'=>'Bamako',
        'MT'=>'Valletta',
        'MH'=>'Majuro',
        'MQ'=>'Fort-de-France',
        'MR'=>'Nouakchott',
        'MU'=>'Port Louis',
        'YT'=>'Mamoudzou',
        'MX'=>'Mexico City',
        'FM'=>'Palikir',
        'MD'=>'Chisinau',
        'MC'=>'Monaco',
        'MN'=>'Ulaanbaatar',
        'ME'=>'Podgorica',
        'MS'=>'Plymouth',
        'MA'=>'Rabat',
        'MZ'=>'Maputo',
        'MM'=>'Naypyidaw',
        'NA'=>'Windhoek',
        'NR'=>'Nauru',
        'NP'=>'Kathmandu',
        'NL'=>'Amsterdam',
        'NC'=>'Nouméa',
        'NZ'=>'Wellington',
        'NI'=>'Managua',
        'NE'=>'Niamey',
        'NG'=>'Abuja',
        'NU'=>'Alofi',
        'NF'=>'Kingston',
        'MP'=>'Saipan',
        'KPP'=>'Pyongyang',
        'NO'=>'Oslo',
        'OM'=>'Muscat',
        'PK'=>'Islamabad',
        'PW'=>'Melekeok',
        'PS'=>'Ramallah; East Jerusalem',
        'PA'=>'Panama City',
        'PG'=>'Port Moresby',
        'PY'=>'Asuncion',
        'PE'=>'Lima',
        'PH'=>'Manila',
        'PN'=>'Adamstown',
        'PL'=>'Warsaw',
        'PT'=>'Lisbon',
        'QA'=>'Doha',
        'RE'=>'Saint-Denis',
        'RO'=>'Bucharest',
        'RU'=>'Moscow',
        'RW'=>'Kigali',
        'WS'=>'Apia',
        'SM'=>'San Marino',
        'ST'=>'Sao Tome',
        'SA'=>'Riyadh',
        'SN'=>'Dakar',
        'RS'=>'Belgrade',
        'SC'=>'Victoria',
        'SL'=>'Freetown',
        'SG'=>'Singapore',
        'SK'=>' Bratislava',
        'SI'=>'Ljubljana',
        'SB'=>'Honiara',
        'SO'=>'Mogadishu',
        'ZA'=>'Pretoria',
        'GS'=>'King Edward Point',
        'KR'=>'Seoul',
        'ES'=>'Madrid',
        'LK'=>'Colombo',
        'BL'=>'Gustavia',
        'SH'=>'Jamestown',
        'KN'=>'Basseterre',
        'LC'=>'Castries',
        'MF'=>'Saint Martin',
        'PM'=>'Saint-Pierre',
        'VC'=>'Kingstown',
        'SD'=>'Khartoum',
        'SR'=>'Paramaribo',
        'SJ'=>'Longyearbyen',
        'SZ'=>'Mbabane',
        'SE'=>'Stockholm',
        'CH'=>'Bern',
        'SY'=>'Damascus',
        'TW'=>'Taipei',
        'TJ'=>'Dushanbe',
        'TZ'=>'Dar es Salaam; Dodoma (legislative)',
        'TH'=>'Bangkok',
        'TL'=>'Dili',
        'TG'=>'Lome',
        'TK'=>'Atafu',
        'TO'=>'Nuku alofa',
        'TT'=>'Port-of-Spain',
        'TN'=>'Tunis',
        'TR'=>'Ankara',
        'TM'=>'Ashgabat',
        'TC'=>'Cockburn Town',
        'TV'=>'Vaiaku village',
        'UG'=>'Kampala',
        'UA'=>'Kyiv',
        'AE'=>'Abu Dhabi',
        'GB'=>'London',
        'US'=>'"Washington D.C',
        'UY'=>'Montevideo',
        'UM'=>'Wake Island',
        'VI'=>'Charlotte Amalie',
        'UZ'=>'Tashkent',
        'VU'=>'Port-Vila',
        'VA'=>'Vatican City',
        'VE'=>'Caracas',
        'VN'=>'Hanoi',
        'WF'=>'Mata Utu',
        'EH'=>'Laayoune',
        'YE'=>'Sanaa',
        'ZM'=>'Lusaka',
        'ZW'=>'Harare'
    );


      /**
     * Collect and get rates
     *
     * @param RateRequest $request
     * @return bool|Result|Error
     */
    public function setRequest(\Magento\Framework\DataObject $request)
    {
        $this->_request = $request;
        $this->setStore($request->getStoreId());

        $requestObject = new \Magento\Framework\DataObject();

        $requestObject->setIsGenerateLabelReturn($request->getIsGenerateLabelReturn());

        $requestObject->setStoreId($request->getStoreId());

        if ($request->getLimitMethod()) {
            $requestObject->setService($request->getLimitMethod());
        }

        $requestObject = $this->_addParams($requestObject);

        if ($request->getDestPostcode()) {
            $requestObject->setDestPostal($request->getDestPostcode());
        }

        $requestObject->setOrigCountry(
            $this->_getDefaultValue($request->getOrigCountry(), Shipment::XML_PATH_STORE_COUNTRY_ID)
        )->setOrigCountryId(
            $this->_getDefaultValue($request->getOrigCountryId(), Shipment::XML_PATH_STORE_COUNTRY_ID)
        );

        $shippingWeight = $request->getPackageWeight();
$dest_city = (isset($this->jordonCityArray[$request->getDestCity()])) ? $this->jordonCityArray[$request->getDestCity()] : $this->CityArrayWW[$request->getDestCountryId()];
        $requestObject->setValue(sprintf('%.2f', $request->getPackageValue()))
            ->setValueWithDiscount($request->getPackageValueWithDiscount())
            ->setCustomsValue($request->getPackageCustomsValue())
            ->setDestStreet($this->string->substr(str_replace("\n", '', $request->getDestStreet()), 0, 35))
            ->setDestStreetLine2($request->getDestStreetLine2())
            ->setDestCity($dest_city)
            ->setOrigCompanyName($request->getOrigCompanyName())
            ->setOrigCity($request->getOrigCity())
            ->setOrigPhoneNumber($request->getOrigPhoneNumber())
            ->setOrigPersonName($request->getOrigPersonName())
            ->setOrigEmail(
                $this->_scopeConfig->getValue(
                    'trans_email/ident_general/email',
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
                    $requestObject->getStoreId()
                )
            )
            ->setOrigCity($request->getOrigCity())
            ->setOrigPostal($request->getOrigPostal())
            ->setOrigStreetLine2($request->getOrigStreetLine2())
            ->setDestPhoneNumber($request->getDestPhoneNumber())
            ->setDestPersonName($request->getDestPersonName())
            ->setDestCompanyName($request->getDestCompanyName());

        $originStreet2 = $this->_scopeConfig->getValue(
            Shipment::XML_PATH_STORE_ADDRESS2,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $requestObject->getStoreId()
        );

        $requestObject->setOrigStreet($request->getOrigStreet() ? $request->getOrigStreet() : $originStreet2);

        if (is_numeric($request->getOrigState())) {
            $requestObject->setOrigState($this->_regionFactory->create()->load($request->getOrigState())->getCode());
        } else {
            $requestObject->setOrigState($request->getOrigState());
        }

        if ($request->getDestCountryId()) {
            $destCountry = $request->getDestCountryId();
        } else {
            $destCountry = self::USA_COUNTRY_ID;
        }

        // for DHL, Puerto Rico state for US will assume as Puerto Rico country
        // for Puerto Rico, dhl will ship as international
        if ($destCountry == self::USA_COUNTRY_ID
            && ($request->getDestPostcode() == '00912' || $request->getDestRegionCode() == self::PUERTORICO_COUNTRY_ID)
        ) {
            $destCountry = self::PUERTORICO_COUNTRY_ID;
        }

        $requestObject->setDestCountryId($destCountry)
            ->setDestState($request->getDestRegionCode())
            ->setWeight($shippingWeight)
            ->setFreeMethodWeight($request->getFreeMethodWeight())
            ->setOrderShipment($request->getOrderShipment());

        if ($request->getPackageId()) {
            $requestObject->setPackageId($request->getPackageId());
        }

        $requestObject->setBaseSubtotalInclTax($request->getBaseSubtotalInclTax());

        $this->setRawRequest($requestObject);

        return $this;
    }
}
