var config = {
    map: {
        '*': {
              'Sts_SmartRoute/template/payment/form.html': 
              'Sunarc_CustomSts/template/payment/form.html'
        }
    }
};