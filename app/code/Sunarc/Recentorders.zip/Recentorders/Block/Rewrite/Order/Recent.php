<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Sunarc\Recentorders\Block\Rewrite\Order;


/**
 * Sales order history block
 *
 * @api
 * @since 100.0.2
 */
class Recent extends \Magento\Sales\Block\Order\Recent
{
   
    /**
     * Get recently placed orders. By default they will be limited by 5.
     */
    private function getCustomRecentOrders()
    {
        $orders = $this->_orderCollectionFactory->create()->addAttributeToSelect(
            '*'
        )->addAttributeToFilter(
            'customer_id',
            $this->_customerSession->getCustomerId()
        // )->addAttributeToFilter(
        //     'store_id',
        //     $this->storeManager->getStore()->getId()
        )->addAttributeToFilter(
            'status',
            ['in' => $this->_orderConfig->getVisibleOnFrontStatuses()]
        )->addAttributeToSort(
            'created_at',
            'desc'
        )->setPageSize(
            self::ORDER_LIMIT
        )->load();
        $this->setOrders($orders);
    }

   protected function _construct()
    {
        parent::_construct();
        $this->getCustomRecentOrders();
    }
    
}
